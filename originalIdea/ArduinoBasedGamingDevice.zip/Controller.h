class Controller
{
  private:
    bool previousRightButtonPressed;
	bool previousLeftButtonPressed;
  public:
    point position;
    bool rightButtonPressed;
	bool leftButtonPressed;
    int size;
    Controller();
    void update();
    bool rightButtonWasPressed;
	bool leftButtonWasPressed;
};
